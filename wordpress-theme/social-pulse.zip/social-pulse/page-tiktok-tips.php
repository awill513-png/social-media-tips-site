<?php /* Template for the 'tiktok-tips' page */ ?>
<?php get_header(); ?>
<main>
    <!-- HERO -->
    <section class="page-hero dark">
      <div class="container hero-grid">
        <div>
          <p class="eyebrow">Platform playbook</p>
          <h1>TikTok tips that keep people <span class="squiggle">watching.</span></h1>
          <p class="lead">TikTok tests every video on a small group of viewers first. If they watch to the end, it shows the video to more people. Here's how to earn that.</p>
          <div class="hero-actions">
            <a href="#hooks" class="btn btn-primary" style="background:var(--cream);color:var(--black);border-color:var(--cream)">Hook formulas →</a>
            <a href="#analytics" class="btn btn-ghost" style="color:var(--cream);border-color:var(--cream)">TikTok analytics</a>
          </div>
        </div>
        <div class="hero-visual">
          <span class="sticker s1">For You page 🚀</span>
          <span class="sticker cream s2">Watched to the end ✓</span>
          <!-- Vertical video phone mockup -->
          <svg viewBox="0 0 360 460" role="img" aria-label="Illustration of a phone playing a vertical short-form video">
            <rect x="70" y="10" width="220" height="440" rx="36" fill="#f6eee2"/>
            <rect x="82" y="22" width="196" height="416" rx="26" fill="#4a2c18"/>
            <circle cx="180" cy="190" r="70" fill="#6b4226"/>
            <circle cx="180" cy="160" r="30" fill="#d9bf9f"/>
            <path d="M120 250 Q180 200 240 250 L240 260 L120 260 Z" fill="#d9bf9f"/>
            <rect x="100" y="70" width="160" height="34" rx="10" fill="#f6eee2"/>
            <text x="180" y="93" text-anchor="middle" font-family="Inter, sans-serif" font-size="14" font-weight="700" fill="#17120e">3 mistakes killing</text>
            <rect x="118" y="108" width="124" height="30" rx="10" fill="#b07b4f"/>
            <text x="180" y="128" text-anchor="middle" font-family="Inter, sans-serif" font-size="14" font-weight="700" fill="#fff">your reach 👇</text>
            <!-- side icons -->
            <g fill="#f6eee2" font-family="Inter, sans-serif" font-size="10" font-weight="600" text-anchor="middle">
              <circle cx="252" cy="300" r="13" fill="#f6eee2"/><text x="252" y="328">48K</text>
              <circle cx="252" cy="350" r="13" fill="#f6eee2"/><text x="252" y="378">1.2K</text>
              <circle cx="252" cy="400" r="13" fill="#b07b4f"/><text x="252" y="428" fill="#f6eee2">9.8K</text>
            </g>
            <path d="M246 299 l6 6 l6-6 a4 4 0 0 0 -6 -5 a4 4 0 0 0 -6 5z" fill="#6b4226"/>
            <rect x="96" y="380" width="120" height="10" rx="5" fill="#f6eee2" opacity=".85"/>
            <rect x="96" y="398" width="86" height="10" rx="5" fill="#f6eee2" opacity=".5"/>
            <!-- progress bar -->
            <rect x="82" y="430" width="196" height="5" fill="#2b211a"/>
            <rect x="82" y="430" width="150" height="5" fill="#b07b4f"/>
          </svg>
        </div>
      </div>
    </section>

    <!-- HOW THE ALGORITHM THINKS -->
    <section class="section">
      <div class="container">
        <div class="section-head reveal">
          <p class="eyebrow">How it works</p>
          <h2>What TikTok rewards</h2>
          <p class="section-intro">Follower count matters less on TikTok than anywhere else. Every video gets a fair shot, and these signals decide how far it goes.</p>
        </div>
        <div class="card-grid">
          <article class="card reveal"><div class="icon"><svg viewBox="0 0 24 24" fill="none" stroke="#6b4226" stroke-width="2.2" stroke-linecap="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg></div><h3>Watch time</h3><p>Did people watch the whole thing, or even twice? This is the #1 signal.</p></article>
          <article class="card reveal"><div class="icon"><svg viewBox="0 0 24 24" fill="none" stroke="#6b4226" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 12v7a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-7"/><path d="M16 6l-4-4-4 4"/><path d="M12 2v13"/></svg></div><h3>Shares</h3><p>Sending a video to a friend is one of the strongest signals that it's worth showing to more people.</p></article>
          <article class="card reveal"><div class="icon"><svg viewBox="0 0 24 24" fill="none" stroke="#6b4226" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a9 9 0 0 1-13.5 7.8L3 21l1.2-4.5A9 9 0 1 1 21 12z"/></svg></div><h3>Comments</h3><p>Conversation keeps a video alive and gives you ideas for reply videos.</p></article>
          <article class="card reveal"><div class="icon"><svg viewBox="0 0 24 24" fill="none" stroke="#6b4226" stroke-width="2.2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/></svg></div><h3>Search match</h3><p>TikTok is a search engine. Keywords you say and show on screen help people find you.</p></article>
        </div>
      </div>
    </section>

    <!-- RETENTION CURVE -->
    <section class="section white">
      <div class="container split">
        <div class="visual-frame cream reveal">
          <svg viewBox="0 0 420 290" role="img" aria-label="Chart comparing a strong hook retention curve that stays high with a weak hook curve that drops quickly">
            <g font-family="Inter, sans-serif" font-size="11" fill="#6f6257">
              <text x="12" y="34">100%</text><text x="18" y="134">50%</text><text x="28" y="234">0%</text>
              <text x="60" y="256">0s</text><text x="160" y="256">5s</text><text x="260" y="256">10s</text><text x="370" y="256">15s</text>
            </g>
            <line x1="60" y1="30" x2="400" y2="30" stroke="#e3d5c1" stroke-dasharray="4 4"/>
            <line x1="60" y1="130" x2="400" y2="130" stroke="#e3d5c1" stroke-dasharray="4 4"/>
            <line x1="60" y1="230" x2="400" y2="230" stroke="#17120e" stroke-width="2"/>
            <!-- strong hook -->
            <path d="M60 30 C 90 40, 110 60, 160 70 S 300 92, 400 104" fill="none" stroke="#6b4226" stroke-width="5" stroke-linecap="round"/>
            <!-- weak hook -->
            <path d="M60 30 C 75 120, 95 170, 160 190 S 300 212, 400 218" fill="none" stroke="#b07b4f" stroke-width="5" stroke-linecap="round" stroke-dasharray="2 10"/>
            <rect x="248" y="56" width="140" height="26" rx="13" fill="#6b4226"/>
            <text x="318" y="73" text-anchor="middle" font-family="Inter, sans-serif" font-size="12" font-weight="700" fill="#fff">Strong hook</text>
            <rect x="248" y="166" width="140" height="26" rx="13" fill="#fff" stroke="#b07b4f" stroke-width="2"/>
            <text x="318" y="183" text-anchor="middle" font-family="Inter, sans-serif" font-size="12" font-weight="700" fill="#6b4226">Weak hook</text>
            <circle cx="95" cy="140" r="16" fill="none" stroke="#17120e" stroke-width="2"/>
            <text x="118" y="146" font-family="Inter, sans-serif" font-size="11" font-weight="700" fill="#17120e">← lost in 2 sec</text>
          </svg>
          <p class="visual-caption">Example retention curves: the percent of viewers still watching over time.</p>
        </div>
        <div class="reveal">
          <p class="eyebrow">Read your retention graph</p>
          <h2>The first 2 seconds decide everything</h2>
          <p class="section-intro">In TikTok Studio, open any video's analytics and look at the retention curve. A steep early drop means your hook needs work. A drop in the middle means the pacing got slow.</p>
          <ul class="tip-list">
            <li>Aim for <strong>more than 70% still watching</strong> at the 3-second mark.</li>
            <li>A bump near the end means people rewatched. That's great!</li>
            <li>Compare your 5 best videos' curves to find your winning pace.</li>
          </ul>
        </div>
      </div>
    </section>

    <!-- HOOK FORMULAS -->
    <section id="hooks" class="section">
      <div class="container">
        <div class="section-head center reveal">
          <p class="eyebrow">Copy &amp; paste</p>
          <h2>6 hook formulas that work</h2>
          <p class="section-intro">Say it out loud <em>and</em> put it on screen in the first second.</p>
        </div>
        <div class="card-grid">
          <article class="card reveal"><span class="sticker" style="margin-bottom:14px">Mistake</span><h3>"Stop doing ___ if you want ___."</h3><p>Fear of missing out on a mistake makes people stay.</p></article>
          <article class="card reveal"><span class="sticker cream" style="margin-bottom:14px">Result first</span><h3>"Here's how I got ___ in ___ days."</h3><p>Show the end result, then explain how you got there.</p></article>
          <article class="card reveal"><span class="sticker black" style="margin-bottom:14px">List</span><h3>"3 ___ nobody tells you about."</h3><p>Numbers tell viewers exactly how long they need to stay.</p></article>
          <article class="card reveal"><span class="sticker" style="margin-bottom:14px">POV</span><h3>"POV: you finally ___."</h3><p>Puts the viewer inside a moment they relate to.</p></article>
          <article class="card reveal"><span class="sticker cream" style="margin-bottom:14px">Hot take</span><h3>"Unpopular opinion: ___."</h3><p>A bold claim gets people commenting, both agreeing and disagreeing.</p></article>
          <article class="card reveal"><span class="sticker black" style="margin-bottom:14px">Curiosity</span><h3>"I tested ___ so you don't have to."</h3><p>People want the answer, so they keep watching to the end.</p></article>
        </div>
      </div>
    </section>

    <!-- VIDEO STRUCTURE TIMELINE -->
    <section class="section dark">
      <div class="container">
        <div class="section-head reveal">
          <p class="eyebrow">Anatomy of a great TikTok</p>
          <h2>Structure your video like this</h2>
        </div>
        <div class="reveal">
          <svg viewBox="0 0 1000 200" role="img" aria-label="Timeline: hook 0 to 2 seconds, setup 2 to 5 seconds, value 5 to 20 seconds, payoff and loop at the end">
            <rect x="0" y="40" width="140" height="70" rx="14" fill="#b07b4f"/>
            <rect x="150" y="40" width="190" height="70" rx="14" fill="#6b4226"/>
            <rect x="350" y="40" width="450" height="70" rx="14" fill="#f6eee2"/>
            <rect x="810" y="40" width="190" height="70" rx="14" fill="#d9bf9f"/>
            <g font-family="Fraunces, Georgia, serif" font-size="24" font-weight="700" text-anchor="middle">
              <text x="70" y="84" fill="#fff">Hook</text>
              <text x="245" y="84" fill="#f6eee2">Setup</text>
              <text x="575" y="84" fill="#17120e">Value</text>
              <text x="905" y="84" fill="#17120e">Payoff + loop</text>
            </g>
            <g font-family="Inter, sans-serif" font-size="15" fill="#d9bf9f" text-anchor="middle">
              <text x="70" y="140">0–2s</text><text x="245" y="140">2–5s</text><text x="575" y="140">5–20s</text><text x="905" y="140">last 2s</text>
              <text x="70" y="166" font-size="13" fill="#9c8a77">Stop the scroll</text>
              <text x="245" y="166" font-size="13" fill="#9c8a77">Why it matters</text>
              <text x="575" y="166" font-size="13" fill="#9c8a77">Deliver fast · cut every pause</text>
              <text x="905" y="166" font-size="13" fill="#9c8a77">End where it began</text>
            </g>
          </svg>
        </div>
        <div class="card-grid" style="margin-top:40px">
          <div class="reveal"><h3>✂️ Cut the dead air</h3><p>Remove every "um," every breath, every pause. Jump cuts keep the pace up.</p></div>
          <div class="reveal"><h3>🔁 Make it loop</h3><p>If the last line flows back into the first, people rewatch without noticing.</p></div>
          <div class="reveal"><h3>🔤 Always add captions</h3><p>Many people scroll with the sound off. On-screen text also helps your video show up in search.</p></div>
        </div>
      </div>
    </section>

    <!-- POSTING TIPS -->
    <section class="section">
      <div class="container split">
        <div class="reveal">
          <p class="eyebrow">Posting tips</p>
          <h2>Tips &amp; tricks for every upload</h2>
          <ul class="tip-list">
            <li><strong>Length:</strong> 7–20 seconds is easiest to watch all the way through. Go longer only if you're telling a story.</li>
            <li><strong>Sounds:</strong> Use trending audio at low volume under your own voice.</li>
            <li><strong>Keywords:</strong> Say them, show them on screen, and put them in the caption.</li>
            <li><strong>Hashtags:</strong> 3–5 specific ones. Skip #fyp, which doesn't help.</li>
            <li><strong>Volume:</strong> Post 1–3 times a day while you're testing. More posts means faster learning.</li>
            <li><strong>Replies:</strong> Turn great comments into "reply with video" posts.</li>
            <li><strong>Series:</strong> Make "Part 1, Part 2…" series so viewers come back for more.</li>
            <li><strong>Cover:</strong> Pick a readable cover frame so your profile grid looks organized.</li>
          </ul>
        </div>
        <div class="reveal">
          <div class="table-wrap">
            <table>
              <thead><tr><th>Day</th><th>Try posting (local time)</th></tr></thead>
              <tbody>
                <tr><td>Mon</td><td>6 AM · 10 AM · 10 PM</td></tr>
                <tr><td>Tue</td><td>9 AM · 2 PM · 7 PM</td></tr>
                <tr><td>Wed</td><td>7 AM · 12 PM · 7 PM</td></tr>
                <tr><td>Thu</td><td>9 AM · 3 PM · 7 PM</td></tr>
                <tr><td>Fri</td><td>5 AM · 1 PM · 3 PM</td></tr>
                <tr><td>Sat</td><td>11 AM · 7 PM · 8 PM</td></tr>
                <tr><td>Sun</td><td>7 AM · 4 PM · 8 PM</td></tr>
              </tbody>
            </table>
          </div>
          <p class="visual-caption">Starting points only. Check the Followers tab in TikTok Studio for your audience's real peak hours.</p>
        </div>
      </div>
    </section>

    <!-- ANALYTICS -->
    <section id="analytics" class="section white">
      <div class="container">
        <div class="section-head reveal">
          <p class="eyebrow">TikTok Studio</p>
          <h2>The TikTok analytics to check</h2>
          <p class="section-intro">Open TikTok Studio from your profile (you'll need a Business or Creator account) and check these for every video.</p>
        </div>
        <div class="table-wrap reveal">
          <table>
            <thead><tr><th>Metric</th><th>What it tells you</th><th>Good sign</th></tr></thead>
            <tbody>
              <tr><td>Average watch time</td><td>How long people stayed</td><td>More than half your video length</td></tr>
              <tr><td>Watched full video</td><td>Percent who reached the end</td><td>Higher than your account's average</td></tr>
              <tr><td>Traffic source</td><td>For You, Following, Search, Profile</td><td>Most views from For You or Search</td></tr>
              <tr><td>Shares</td><td>How many people sent it to friends</td><td>Shares growing faster than likes</td></tr>
              <tr><td>New followers</td><td>Followers gained from this video</td><td>Spikes on series or "how-to" content</td></tr>
              <tr><td>Search terms</td><td>What viewers searched to find you</td><td>Use these words in future videos</td></tr>
            </tbody>
          </table>
        </div>
      </div>
    </section>

    <!-- DO / DON'T -->
    <section class="section">
      <div class="container">
        <div class="section-head center reveal"><p class="eyebrow">Quick guide</p><h2>Do this, not that</h2></div>
        <div class="do-dont reveal">
          <div class="do"><h3>✅ Do</h3><ul>
            <li>Start with the most interesting moment</li>
            <li>Film vertically (9:16) in good light</li>
            <li>Reply to comments in the first hour</li>
            <li>Join trends early and add your own twist</li>
            <li>Check your analytics weekly and adjust</li>
          </ul></div>
          <div class="dont"><h3>🚫 Don't</h3><ul>
            <li>Open with "Hey guys, so today…"</li>
            <li>Repost videos with another app's watermark</li>
            <li>Delete videos that flop (it can hurt your account)</li>
            <li>Use #fyp or dozens of off-topic hashtags</li>
            <li>Give up after 5 videos, because TikTok rewards volume</li>
          </ul></div>
        </div>
      </div>
    </section>

    <section class="section" style="padding-top:0">
      <div class="container">
        <div class="cta-band reveal">
          <div><h2>Posting Reels too?</h2><p>Instagram rewards different things. Here's the playbook.</p></div>
          <a href="<?php echo esc_url(home_url('/instagram-tips/')); ?>" class="btn btn-primary">Instagram tips →</a>
        </div>
      </div>
    </section>
  </main>
<?php get_footer(); ?>

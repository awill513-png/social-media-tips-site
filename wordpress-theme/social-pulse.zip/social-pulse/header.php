<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>


  <header class="site-header">
    <div class="container nav-wrap">
      <a href="<?php echo esc_url(home_url('/')); ?>" class="logo"><span class="logo-mark"><svg viewBox="0 0 24 24"><path d="M3 17l5-5 4 4 8-9" fill="none" stroke="#17120e" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/></svg></span>Social Pulse</a>
      <button class="nav-toggle" aria-label="Open menu" aria-expanded="false">☰</button>
      <nav class="site-nav">
        <a href="<?php echo esc_url(home_url('/')); ?>">Home</a>
        <a href="<?php echo esc_url(home_url('/about/')); ?>">About</a>
        <a href="<?php echo esc_url(home_url('/tiktok-tips/')); ?>">TikTok Tips</a>
        <a href="<?php echo esc_url(home_url('/instagram-tips/')); ?>">Instagram Tips</a>
      </nav>
    </div>
  </header>

  
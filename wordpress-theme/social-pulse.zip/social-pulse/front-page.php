<?php get_header(); ?>
<main>
    <!-- HERO -->
    <section class="hero">
      <div class="hero-blob"></div>
      <div class="container hero-grid">
        <div>
          <p class="eyebrow">Social media analytics, made simple</p>
          <h1>Stop guessing.<br><span class="squiggle">Post with data.</span></h1>
          <p class="lead">Learn which numbers actually matter, how to read your insights, and the tips that help your posts get seen, saved and shared.</p>
          <div class="hero-actions">
            <a href="#metrics" class="btn btn-primary">Learn the metrics →</a>
            <a href="<?php echo esc_url(home_url('/tiktok-tips/')); ?>" class="btn btn-ghost">Get posting tips</a>
          </div>
        </div>

        <div class="hero-visual">
          <span class="sticker s1">+312 followers ✨</span>
          <span class="sticker cream s2">5.7% engagement 🔥</span>
          <!-- Phone dashboard illustration -->
          <svg viewBox="0 0 360 460" role="img" aria-label="Illustration of a phone showing a social media analytics dashboard">
            <rect x="40" y="10" width="280" height="440" rx="40" fill="#17120e"/>
            <rect x="54" y="24" width="252" height="412" rx="28" fill="#f6eee2"/>
            <rect x="140" y="34" width="80" height="14" rx="7" fill="#17120e"/>
            <text x="76" y="86" font-family="Inter, sans-serif" font-size="13" fill="#6f6257" font-weight="600">INSIGHTS · LAST 7 DAYS</text>
            <text x="76" y="124" font-family="Fraunces, Georgia, serif" font-size="36" font-weight="700" fill="#17120e">48.2K</text>
            <text x="198" y="124" font-family="Inter, sans-serif" font-size="13" fill="#6b4226" font-weight="700">▲ 24%</text>
            <text x="76" y="144" font-family="Inter, sans-serif" font-size="12" fill="#6f6257">accounts reached</text>
            <!-- line chart -->
            <path d="M76 240 L110 222 L144 230 L178 196 L212 204 L246 168 L284 150 L284 260 L76 260 Z" fill="#d9bf9f" opacity=".55"/>
            <path d="M76 240 L110 222 L144 230 L178 196 L212 204 L246 168 L284 150" fill="none" stroke="#6b4226" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>
            <circle cx="284" cy="150" r="7" fill="#b07b4f" stroke="#17120e" stroke-width="3"/>
            <line x1="76" y1="260" x2="284" y2="260" stroke="#e3d5c1" stroke-width="2"/>
            <!-- donut -->
            <circle cx="118" cy="340" r="34" fill="none" stroke="#ecdfcb" stroke-width="14"/>
            <circle cx="118" cy="340" r="34" fill="none" stroke="#6b4226" stroke-width="14" stroke-dasharray="132 214" transform="rotate(-90 118 340)" stroke-linecap="round"/>
            <text x="118" y="346" text-anchor="middle" font-family="Fraunces, Georgia, serif" font-size="17" font-weight="700" fill="#17120e">62%</text>
            <text x="172" y="330" font-family="Inter, sans-serif" font-size="12" fill="#6f6257">reached people</text>
            <text x="172" y="348" font-family="Inter, sans-serif" font-size="12" fill="#6f6257">who don't follow</text>
            <text x="172" y="366" font-family="Inter, sans-serif" font-size="12" fill="#6b4226" font-weight="700">you yet</text>
            <!-- bottom pills -->
            <rect x="76" y="396" width="64" height="24" rx="12" fill="#17120e"/>
            <text x="108" y="412" text-anchor="middle" font-family="Inter, sans-serif" font-size="11" fill="#f6eee2" font-weight="600">♥ 2.1K</text>
            <rect x="148" y="396" width="64" height="24" rx="12" fill="#b07b4f"/>
            <text x="180" y="412" text-anchor="middle" font-family="Inter, sans-serif" font-size="11" fill="#fff" font-weight="600">↗ 486</text>
            <rect x="220" y="396" width="64" height="24" rx="12" fill="#fff" stroke="#17120e" stroke-width="1.5"/>
            <text x="252" y="412" text-anchor="middle" font-family="Inter, sans-serif" font-size="11" fill="#17120e" font-weight="600">⚑ 730</text>
          </svg>
        </div>
      </div>
    </section>

    <!-- STATS STRIP -->
    <section class="container reveal" style="margin-top:-24px">
      <div class="stats-strip">
        <div class="stat"><strong>1.5s</strong><span>to stop someone scrolling</span></div>
        <div class="stat"><strong>3–6%</strong><span>a strong engagement rate</span></div>
        <div class="stat"><strong>15 min</strong><span>a week to review your data</span></div>
        <div class="stat"><strong>1</strong><span>change to test at a time</span></div>
      </div>
    </section>

    <!-- METRICS -->
    <section id="metrics" class="section">
      <div class="container">
        <div class="section-head reveal">
          <p class="eyebrow">Analytics 101</p>
          <h2>The metrics that actually matter</h2>
          <p class="section-intro">Your insights tab shows dozens of numbers. These six are worth checking every week.</p>
        </div>
        <div class="card-grid">
          <article class="card reveal">
            <div class="icon"><svg viewBox="0 0 24 24" fill="none" stroke="#6b4226" stroke-width="2.2" stroke-linecap="round"><circle cx="12" cy="12" r="3"/><path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z"/></svg></div>
            <h3>Reach</h3>
            <p>How many <em>different</em> accounts saw your post. This is how far your content travels.</p>
            <p class="tip"><strong>Watch:</strong> reach from non-followers. That's how new people find you.</p>
          </article>
          <article class="card reveal">
            <div class="icon"><svg viewBox="0 0 24 24" fill="none" stroke="#6b4226" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a9 9 0 0 1-13.5 7.8L3 21l1.2-4.5A9 9 0 1 1 21 12z"/></svg></div>
            <h3>Engagement rate</h3>
            <p>Likes + comments + shares + saves, divided by reach. The best single measure of how much people care about a post.</p>
            <p class="tip"><strong>Benchmark:</strong> 1–3% is average, 3–6% is strong, and 6% or more is excellent.</p>
          </article>
          <article class="card reveal">
            <div class="icon"><svg viewBox="0 0 24 24" fill="none" stroke="#6b4226" stroke-width="2.2" stroke-linejoin="round"><path d="M6 3h12v18l-6-4-6 4z"/></svg></div>
            <h3>Saves &amp; shares</h3>
            <p>The strongest signals to the algorithm. They mean "worth coming back to" or "my friends need this."</p>
            <p class="tip"><strong>Watch:</strong> which formats get saved most. Make more of those.</p>
          </article>
          <article class="card reveal">
            <div class="icon"><svg viewBox="0 0 24 24" fill="none" stroke="#6b4226" stroke-width="2.2" stroke-linecap="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg></div>
            <h3>Watch time</h3>
            <p>For video: average view duration and the percent who watch to the end.</p>
            <p class="tip"><strong>Watch:</strong> the drop-off point on your retention graph.</p>
          </article>
          <article class="card reveal">
            <div class="icon"><svg viewBox="0 0 24 24" fill="none" stroke="#6b4226" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 17l6-6 4 4 8-8"/><path d="M15 7h6v6"/></svg></div>
            <h3>Follower growth rate</h3>
            <p>New followers ÷ starting followers over a set period. More useful than your total follower count.</p>
            <p class="tip"><strong>Watch:</strong> spikes. Find the post that caused them.</p>
          </article>
          <article class="card reveal">
            <div class="icon"><svg viewBox="0 0 24 24" fill="none" stroke="#6b4226" stroke-width="2.2" stroke-linecap="round"><circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1.5" fill="#6b4226"/></svg></div>
            <h3>Clicks &amp; conversions</h3>
            <p>Link taps, sign-ups and sales that came from social. Track them with UTM links.</p>
            <p class="tip"><strong>Watch:</strong> which platform drives action, not just likes.</p>
          </article>
        </div>
      </div>
    </section>

    <!-- FUNNEL + STEPS -->
    <section class="section white">
      <div class="container split">
        <div class="reveal">
          <p class="eyebrow">The big picture</p>
          <h2>How one post turns into results</h2>
          <p class="section-intro">Every metric fits somewhere in this funnel. When results are weak, find the stage where people drop off and fix that first.</p>
          <ul class="tip-list">
            <li><strong>Low reach?</strong> Work on hooks, timing and trending formats.</li>
            <li><strong>Reach is fine but engagement is low?</strong> Your content isn't delivering on its hook.</li>
            <li><strong>Engagement is fine but clicks are low?</strong> Make the call-to-action clearer.</li>
          </ul>
        </div>
        <div class="visual-frame cream reveal">
          <svg viewBox="0 0 400 330" role="img" aria-label="Funnel diagram: reach, engagement, clicks, conversions">
            <path d="M20 20 H380 L350 90 H50 Z" fill="#17120e"/>
            <text x="200" y="62" text-anchor="middle" font-family="Fraunces, Georgia, serif" font-size="20" font-weight="700" fill="#f6eee2">Reach</text>
            <path d="M54 100 H346 L316 170 H84 Z" fill="#6b4226"/>
            <text x="200" y="142" text-anchor="middle" font-family="Fraunces, Georgia, serif" font-size="20" font-weight="700" fill="#f6eee2">Engagement</text>
            <path d="M88 180 H312 L282 250 H118 Z" fill="#b07b4f"/>
            <text x="200" y="222" text-anchor="middle" font-family="Fraunces, Georgia, serif" font-size="20" font-weight="700" fill="#fff">Clicks</text>
            <path d="M122 260 H278 L250 320 H150 Z" fill="#d9bf9f" stroke="#17120e" stroke-width="2"/>
            <text x="200" y="296" text-anchor="middle" font-family="Fraunces, Georgia, serif" font-size="18" font-weight="700" fill="#17120e">Results</text>
          </svg>
        </div>
      </div>
    </section>

    <section class="section">
      <div class="container narrow">
        <div class="section-head reveal">
          <p class="eyebrow">Your weekly routine</p>
          <h2>Read your analytics in 15 minutes</h2>
        </div>
        <div class="steps">
          <div class="step reveal"><span class="step-num">1</span><div><h3>Pick one goal per platform</h3><p>Awareness (reach), community (engagement), or action (clicks). Judge each platform by its own goal.</p></div></div>
          <div class="step reveal"><span class="step-num">2</span><div><h3>Find your top 3 and bottom 3 posts</h3><p>Sort by engagement rate, not likes. Note what the winners share: format, topic, hook, length or time.</p></div></div>
          <div class="step reveal"><span class="step-num">3</span><div><h3>Compare to your own average</h3><p>A post doing twice your usual numbers is a hit, even if the numbers look small next to big creators.</p></div></div>
          <div class="step reveal"><span class="step-num">4</span><div><h3>Check where viewers came from</h3><p>Feed, Explore/For You, hashtags, search or your profile. This shows which discovery channel to focus on.</p></div></div>
          <div class="step reveal"><span class="step-num">5</span><div><h3>Run one experiment</h3><p>Change only one thing next week (hook, time, format or caption length) and compare.</p></div></div>
        </div>
        <div class="callout reveal">
          <span class="callout-icon">💡</span>
          <div><strong>Pro trick:</strong> Keep a simple spreadsheet with these columns: Date · Platform · Format · Topic · Hook · Reach · Eng. rate · Saves · Notes. After a month, patterns jump out.</div>
        </div>
      </div>
    </section>

    <!-- HEATMAP -->
    <section class="section dark">
      <div class="container split">
        <div class="reveal">
          <p class="eyebrow">Timing</p>
          <h2>When should you post?</h2>
          <p class="section-intro">Common starting points are weekday mornings, lunch, and evenings after 6 PM. Your audience is unique, so check the "Most active times" section of your insights and test from there.</p>
          <ul class="tip-list">
            <li>Post 30–60 minutes <em>before</em> your audience peaks.</li>
            <li>Stay online for 15–30 minutes after posting to reply.</li>
            <li>Being consistent matters more than finding the perfect minute.</li>
          </ul>
        </div>
        <div class="reveal">
          <div class="heatmap" role="img" aria-label="Example heatmap of audience activity by day and time; darker means more active">
            <span></span><span class="hl">6a</span><span class="hl">9a</span><span class="hl">12p</span><span class="hl">3p</span><span class="hl">6p</span><span class="hl">9p</span>
            <span class="dl">Mon</span><i style="--v:.15"></i><i style="--v:.55"></i><i style="--v:.6"></i><i style="--v:.35"></i><i style="--v:.7"></i><i style="--v:.5"></i>
            <span class="dl">Tue</span><i style="--v:.2"></i><i style="--v:.75"></i><i style="--v:.65"></i><i style="--v:.4"></i><i style="--v:.85"></i><i style="--v:.6"></i>
            <span class="dl">Wed</span><i style="--v:.2"></i><i style="--v:.8"></i><i style="--v:.7"></i><i style="--v:.45"></i><i style="--v:.95"></i><i style="--v:.65"></i>
            <span class="dl">Thu</span><i style="--v:.2"></i><i style="--v:.7"></i><i style="--v:.75"></i><i style="--v:.5"></i><i style="--v:.9"></i><i style="--v:.7"></i>
            <span class="dl">Fri</span><i style="--v:.15"></i><i style="--v:.6"></i><i style="--v:.6"></i><i style="--v:.45"></i><i style="--v:.65"></i><i style="--v:.55"></i>
            <span class="dl">Sat</span><i style="--v:.1"></i><i style="--v:.35"></i><i style="--v:.55"></i><i style="--v:.5"></i><i style="--v:.5"></i><i style="--v:.45"></i>
            <span class="dl">Sun</span><i style="--v:.1"></i><i style="--v:.3"></i><i style="--v:.5"></i><i style="--v:.45"></i><i style="--v:.6"></i><i style="--v:.55"></i>
          </div>
          <p class="visual-caption" style="color:#b9a48c">Example audience activity. Darker squares mean more people are online.</p>
        </div>
      </div>
    </section>

    <!-- CALCULATOR -->
    <section id="calculator" class="section">
      <div class="container split">
        <div class="reveal">
          <p class="eyebrow">Free tool</p>
          <h2>Engagement rate calculator</h2>
          <p class="section-intro">Enter a post's numbers to see how it performed. Use reach for the most accurate rate, or followers if reach isn't available.</p>
          <ul class="formula">
            <li>(likes + comments + shares + saves) ÷ reach × 100</li>
          </ul>
        </div>
        <form class="calc reveal" id="calcForm">
          <div class="field-row">
            <label>Likes<input type="number" min="0" id="likes" placeholder="0"></label>
            <label>Comments<input type="number" min="0" id="comments" placeholder="0"></label>
          </div>
          <div class="field-row">
            <label>Shares<input type="number" min="0" id="shares" placeholder="0"></label>
            <label>Saves<input type="number" min="0" id="saves" placeholder="0"></label>
          </div>
          <label>Reach (or followers)<input type="number" min="1" id="base" placeholder="e.g. 5000"></label>
          <button type="submit" class="btn btn-primary full">Calculate</button>
          <div class="result" id="calcResult" aria-live="polite">Your result will appear here.</div>
        </form>
      </div>
    </section>

    <!-- UNIVERSAL TIPS -->
    <section class="section white">
      <div class="container">
        <div class="section-head center reveal">
          <p class="eyebrow">Works everywhere</p>
          <h2>Universal posting tricks</h2>
        </div>
        <div class="card-grid">
          <article class="card cream reveal"><h3>🪝 Hook first</h3><p>Open with a question, a surprising number, a bold claim, or the end result.</p></article>
          <article class="card cream reveal"><h3>♻️ Repurpose</h3><p>One idea can become a Reel, a TikTok, a carousel and a Story series.</p></article>
          <article class="card cream reveal"><h3>📣 Clear CTA</h3><p>"Save this for later." "Send to a friend who…" Tell people exactly what to do.</p></article>
          <article class="card cream reveal"><h3>📅 Consistency</h3><p>Posting 3 times a week, every week, beats 10 posts one week and nothing for a month.</p></article>
          <article class="card cream reveal"><h3>🧪 80/20 rule</h3><p>Make 80% of posts proven formats and 20% experiments. Your analytics tell you which is which.</p></article>
          <article class="card cream reveal"><h3>🔗 UTM links</h3><p>Tag links with <code>?utm_source=tiktok</code> so you can see which platform drives traffic.</p></article>
        </div>
      </div>
    </section>

    <!-- CTA -->
    <section class="section">
      <div class="container">
        <div class="cta-band reveal">
          <div>
            <h2>Ready to dive into a platform?</h2>
            <p>Get the full playbook for the app you post on most.</p>
          </div>
          <div class="hero-actions">
            <a href="<?php echo esc_url(home_url('/tiktok-tips/')); ?>" class="btn btn-primary">TikTok tips →</a>
            <a href="<?php echo esc_url(home_url('/instagram-tips/')); ?>" class="btn btn-ghost">Instagram tips →</a>
          </div>
        </div>
      </div>
    </section>
  </main>
<?php get_footer(); ?>

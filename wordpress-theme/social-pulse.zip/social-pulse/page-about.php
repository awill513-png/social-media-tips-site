<?php /* Template for the 'about' page */ ?>
<?php get_header(); ?>
<main>
    <section class="page-hero">
      <div class="container hero-grid">
        <div>
          <p class="eyebrow">About Social Pulse</p>
          <h1>Analytics without the <span class="squiggle">overwhelm.</span></h1>
          <p class="lead">Social Pulse turns confusing dashboards into clear, friendly advice, so you can spend less time guessing and more time making posts you're proud of.</p>
        </div>
        <div class="hero-visual">
          <span class="sticker s1">Data 🤝 Creativity</span>
          <!-- Illustration: magnifying glass over chart -->
          <svg viewBox="0 0 360 340" role="img" aria-label="Illustration of a magnifying glass over a bar chart">
            <rect x="20" y="30" width="300" height="260" rx="28" fill="#fff" stroke="#17120e" stroke-width="3"/>
            <rect x="60" y="190" width="36" height="70" rx="6" fill="#d9bf9f"/>
            <rect x="110" y="150" width="36" height="110" rx="6" fill="#b07b4f"/>
            <rect x="160" y="170" width="36" height="90" rx="6" fill="#d9bf9f"/>
            <rect x="210" y="110" width="36" height="150" rx="6" fill="#6b4226"/>
            <rect x="260" y="80" width="36" height="180" rx="6" fill="#17120e"/>
            <line x1="50" y1="262" x2="300" y2="262" stroke="#17120e" stroke-width="3"/>
            <circle cx="230" cy="130" r="58" fill="#f6eee2" fill-opacity=".55" stroke="#17120e" stroke-width="10"/>
            <line x1="272" y1="172" x2="330" y2="230" stroke="#17120e" stroke-width="16" stroke-linecap="round"/>
            <path d="M200 120 l14 14 l26 -30" fill="none" stroke="#6b4226" stroke-width="7" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
        </div>
      </div>
    </section>

    <section class="section white">
      <div class="container split">
        <div class="reveal">
          <p class="eyebrow">Our story</p>
          <h2>Why this site exists</h2>
          <p>Every app has an insights tab, but very few people know what to do with it. Numbers like "reach," "impressions" and "engagement rate" sound technical, and most advice online is either too vague or tries to sell you something.</p>
          <p>Social Pulse was created to fix that. It's a simple, honest guide to social media analytics plus practical posting tips you can use today, whether you're a student, a creator, a small business or managing a brand's account.</p>
        </div>
        <div class="reveal">
          <div class="stats-strip" style="grid-template-columns:1fr 1fr">
            <div class="stat" style="border-bottom:2px solid var(--black)"><strong>2</strong><span>platform playbooks</span></div>
            <div class="stat" style="border-right:0;border-bottom:2px solid var(--black)"><strong>6</strong><span>core metrics explained</span></div>
            <div class="stat"><strong>1</strong><span>free engagement calculator</span></div>
            <div class="stat" style="border-right:0"><strong>$0</strong><span>cost, always free</span></div>
          </div>
        </div>
      </div>
    </section>

    <section class="section">
      <div class="container">
        <div class="section-head center reveal"><p class="eyebrow">What we believe</p><h2>Our approach</h2></div>
        <div class="value-grid">
          <article class="card reveal">
            <div class="icon"><svg viewBox="0 0 24 24" fill="none" stroke="#6b4226" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 17l6-6 4 4 8-8"/><path d="M15 7h6v6"/></svg></div>
            <h3>Data, explained simply</h3>
            <p>Every metric is explained in plain English, with what it means and what to do about it.</p>
          </article>
          <article class="card reveal">
            <div class="icon"><svg viewBox="0 0 24 24" fill="none" stroke="#6b4226" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2l2.9 6.9L22 10l-5.5 4.8L18 22l-6-3.6L6 22l1.5-7.2L2 10l7.1-1.1z"/></svg></div>
            <h3>Creativity first</h3>
            <p>Analytics should guide your ideas, not replace them. Use the numbers to make better posts, not to copy everyone else.</p>
          </article>
          <article class="card reveal">
            <div class="icon"><svg viewBox="0 0 24 24" fill="none" stroke="#6b4226" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg></div>
            <h3>Honest &amp; ethical</h3>
            <p>No fake followers, no engagement bait, no shortcuts. Only real strategies that build a real audience.</p>
          </article>
        </div>
      </div>
    </section>

    <section class="section dark">
      <div class="container">
        <p class="quote reveal">The best strategy isn't posting more. It's learning from every post you've already made.</p>
      </div>
    </section>

    <section class="section">
      <div class="container narrow">
        <div class="section-head reveal"><p class="eyebrow">Who it's for</p><h2>Made for anyone who posts</h2></div>
        <div class="steps">
          <div class="step reveal"><span class="step-num">🎓</span><div><h3>Students</h3><p>Learning digital marketing or growing a personal brand.</p></div></div>
          <div class="step reveal"><span class="step-num">🎥</span><div><h3>Creators</h3><p>Trying to understand why one video takes off and another doesn't.</p></div></div>
          <div class="step reveal"><span class="step-num">🛍️</span><div><h3>Small businesses</h3><p>Turning followers into customers without a big marketing budget.</p></div></div>
          <div class="step reveal"><span class="step-num">💼</span><div><h3>Social media managers</h3><p>Needing a quick, shareable reference for clients and teams.</p></div></div>
        </div>
      </div>
    </section>

    <section class="section" style="padding-top:0">
      <div class="container">
        <div class="cta-band reveal">
          <div><h2>Start with the basics</h2><p>Learn the 6 metrics that matter, then try the calculator.</p></div>
          <a href="<?php echo esc_url(home_url('/')); ?>#metrics" class="btn btn-primary">Explore metrics →</a>
        </div>
      </div>
    </section>
  </main>
<?php get_footer(); ?>

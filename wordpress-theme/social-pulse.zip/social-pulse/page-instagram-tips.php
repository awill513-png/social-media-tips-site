<?php /* Template for the 'instagram-tips' page */ ?>
<?php get_header(); ?>
<main>
    <!-- HERO -->
    <section class="page-hero">
      <div class="container hero-grid">
        <div>
          <p class="eyebrow">Platform playbook</p>
          <h1>Instagram tips worth <span class="squiggle">saving.</span></h1>
          <p class="lead">Reels for reach, carousels for saves, Stories for connection. Learn what each format does best and how to read your insights.</p>
          <div class="hero-actions">
            <a href="#formats" class="btn btn-primary">Compare formats →</a>
            <a href="#checklist" class="btn btn-ghost">Pre-post checklist</a>
          </div>
        </div>
        <div class="hero-visual">
          <span class="sticker s1">Saved 730× 🔖</span>
          <span class="sticker black s2">Sent in DMs 💌</span>
          <!-- Profile grid mockup -->
          <svg viewBox="0 0 360 460" role="img" aria-label="Illustration of an Instagram-style profile with a cohesive brown and cream grid">
            <rect x="40" y="10" width="280" height="440" rx="40" fill="#17120e"/>
            <rect x="54" y="24" width="252" height="412" rx="28" fill="#ffffff"/>
            <circle cx="98" cy="88" r="28" fill="#d9bf9f" stroke="#b07b4f" stroke-width="4"/>
            <circle cx="98" cy="80" r="10" fill="#6b4226"/><path d="M80 104 Q98 88 116 104" fill="#6b4226"/>
            <g font-family="Inter, sans-serif" text-anchor="middle">
              <text x="160" y="84" font-size="15" font-weight="700" fill="#17120e">128</text><text x="160" y="100" font-size="10" fill="#6f6257">posts</text>
              <text x="212" y="84" font-size="15" font-weight="700" fill="#17120e">24.6K</text><text x="212" y="100" font-size="10" fill="#6f6257">followers</text>
              <text x="264" y="84" font-size="15" font-weight="700" fill="#17120e">310</text><text x="264" y="100" font-size="10" fill="#6f6257">following</text>
            </g>
            <rect x="72" y="130" width="140" height="9" rx="4" fill="#17120e"/>
            <rect x="72" y="146" width="200" height="7" rx="3.5" fill="#e3d5c1"/>
            <rect x="72" y="160" width="160" height="7" rx="3.5" fill="#e3d5c1"/>
            <!-- highlights -->
            <g stroke="#e3d5c1" stroke-width="2.5">
              <circle cx="92" cy="200" r="16" fill="#f6eee2"/><circle cx="138" cy="200" r="16" fill="#d9bf9f"/><circle cx="184" cy="200" r="16" fill="#b07b4f"/><circle cx="230" cy="200" r="16" fill="#6b4226"/>
            </g>
            <!-- grid -->
            <rect x="62" y="232" width="78" height="96" fill="#6b4226"/>
            <rect x="141" y="232" width="78" height="96" fill="#f6eee2"/>
            <rect x="220" y="232" width="78" height="96" fill="#17120e"/>
            <rect x="62" y="329" width="78" height="96" fill="#d9bf9f"/>
            <rect x="141" y="329" width="78" height="96" fill="#b07b4f"/>
            <rect x="220" y="329" width="78" height="96" fill="#ecdfcb"/>
            <text x="180" y="286" text-anchor="middle" font-family="Fraunces, Georgia, serif" font-size="16" font-weight="700" fill="#6b4226">5 tips</text>
            <text x="259" y="286" text-anchor="middle" font-family="Fraunces, Georgia, serif" font-size="16" font-weight="700" fill="#f6eee2">Save!</text>
            <path d="M93 270 l14 10 l-14 10z" fill="#f6eee2"/>
            <path d="M172 368 l14 10 l-14 10z" fill="#fff"/>
            <rect x="282" y="236" width="12" height="10" rx="2" fill="none" stroke="#f6eee2" stroke-width="1.6"/>
          </svg>
        </div>
      </div>
    </section>

    <!-- WHAT IG REWARDS -->
    <section class="section dark">
      <div class="container">
        <div class="section-head reveal">
          <p class="eyebrow">How it works</p>
          <h2>What Instagram rewards</h2>
          <p class="section-intro">Instagram has said that sends (shares in DMs), watch time and likes are among its biggest ranking signals. Saves show your content is worth keeping.</p>
        </div>
        <div class="card-grid">
          <article class="card brown reveal"><h3>💌 Sends</h3><p>Shares in DMs are the top signal for reaching people who don't follow you. Make content people want to send to a friend.</p></article>
          <article class="card brown reveal"><h3>⏱️ Watch time</h3><p>For Reels, how long people watch and whether they rewatch.</p></article>
          <article class="card brown reveal"><h3>🔖 Saves</h3><p>Tutorials, checklists and tips get saved. Saves show Instagram that a post has lasting value.</p></article>
          <article class="card brown reveal"><h3>❤️ Likes &amp; comments</h3><p>These matter most for reaching your existing followers. Reply to keep the conversation going.</p></article>
        </div>
      </div>
    </section>

    <!-- FORMATS -->
    <section id="formats" class="section">
      <div class="container">
        <div class="section-head reveal">
          <p class="eyebrow">Choose your format</p>
          <h2>What each format is best for</h2>
          <p class="section-intro">Use each format for its strength. A good mix is Reels to grow, carousels to teach and Stories to connect.</p>
        </div>
        <div class="visual-frame reveal" style="box-shadow:none">
          <svg viewBox="0 0 900 300" role="img" aria-label="Rating chart: Reels are strongest for reach, carousels for saves, Stories for connection, single photos for brand look">
            <g font-family="Inter, sans-serif" font-size="13" font-weight="700" fill="#6f6257" text-anchor="middle" letter-spacing="1">
              <text x="330" y="30">REACH</text><text x="480" y="30">SAVES</text><text x="630" y="30">CONNECTION</text><text x="790" y="30">EFFORT</text>
            </g>
            <g font-family="Fraunces, Georgia, serif" font-size="22" font-weight="700" fill="#17120e">
              <text x="20" y="92">🎬 Reels</text><text x="20" y="152">📚 Carousels</text><text x="20" y="212">⭕ Stories</text><text x="20" y="272">🖼️ Single photo</text>
            </g>
            <g stroke="#e3d5c1" stroke-width="1"><line x1="20" y1="118" x2="880" y2="118"/><line x1="20" y1="178" x2="880" y2="178"/><line x1="20" y1="238" x2="880" y2="238"/></g>
            <!-- dots: 5 per cell, filled = rating -->
            <g id="dots"></g>
            <!-- Reels: reach 5, saves 3, conn 3, effort 5 -->
            <g fill="#6b4226">
              <circle cx="290" cy="85" r="8"/><circle cx="310" cy="85" r="8"/><circle cx="330" cy="85" r="8"/><circle cx="350" cy="85" r="8"/><circle cx="370" cy="85" r="8"/>
              <circle cx="440" cy="85" r="8"/><circle cx="460" cy="85" r="8"/><circle cx="480" cy="85" r="8"/>
              <circle cx="590" cy="85" r="8"/><circle cx="610" cy="85" r="8"/><circle cx="630" cy="85" r="8"/>
            </g>
            <g fill="#b07b4f">
              <circle cx="750" cy="85" r="8"/><circle cx="770" cy="85" r="8"/><circle cx="790" cy="85" r="8"/><circle cx="810" cy="85" r="8"/><circle cx="830" cy="85" r="8"/>
            </g>
            <!-- Carousels: reach 3, saves 5, conn 3, effort 3 -->
            <g fill="#6b4226">
              <circle cx="290" cy="145" r="8"/><circle cx="310" cy="145" r="8"/><circle cx="330" cy="145" r="8"/>
              <circle cx="440" cy="145" r="8"/><circle cx="460" cy="145" r="8"/><circle cx="480" cy="145" r="8"/><circle cx="500" cy="145" r="8"/><circle cx="520" cy="145" r="8"/>
              <circle cx="590" cy="145" r="8"/><circle cx="610" cy="145" r="8"/><circle cx="630" cy="145" r="8"/>
            </g>
            <g fill="#b07b4f"><circle cx="750" cy="145" r="8"/><circle cx="770" cy="145" r="8"/><circle cx="790" cy="145" r="8"/></g>
            <!-- Stories: reach 1, saves 1, conn 5, effort 1 -->
            <g fill="#6b4226">
              <circle cx="290" cy="205" r="8"/>
              <circle cx="440" cy="205" r="8"/>
              <circle cx="590" cy="205" r="8"/><circle cx="610" cy="205" r="8"/><circle cx="630" cy="205" r="8"/><circle cx="650" cy="205" r="8"/><circle cx="670" cy="205" r="8"/>
            </g>
            <g fill="#b07b4f"><circle cx="750" cy="205" r="8"/></g>
            <!-- Single: reach 2, saves 2, conn 2, effort 2 -->
            <g fill="#6b4226">
              <circle cx="290" cy="265" r="8"/><circle cx="310" cy="265" r="8"/>
              <circle cx="440" cy="265" r="8"/><circle cx="460" cy="265" r="8"/>
              <circle cx="590" cy="265" r="8"/><circle cx="610" cy="265" r="8"/>
            </g>
            <g fill="#b07b4f"><circle cx="750" cy="265" r="8"/><circle cx="770" cy="265" r="8"/></g>
            <!-- empty dots -->
            <g fill="none" stroke="#d9bf9f" stroke-width="2">
              <circle cx="500" cy="85" r="7"/><circle cx="520" cy="85" r="7"/><circle cx="650" cy="85" r="7"/><circle cx="670" cy="85" r="7"/>
              <circle cx="350" cy="145" r="7"/><circle cx="370" cy="145" r="7"/><circle cx="650" cy="145" r="7"/><circle cx="670" cy="145" r="7"/><circle cx="810" cy="145" r="7"/><circle cx="830" cy="145" r="7"/>
              <circle cx="310" cy="205" r="7"/><circle cx="330" cy="205" r="7"/><circle cx="350" cy="205" r="7"/><circle cx="370" cy="205" r="7"/><circle cx="460" cy="205" r="7"/><circle cx="480" cy="205" r="7"/><circle cx="500" cy="205" r="7"/><circle cx="520" cy="205" r="7"/><circle cx="770" cy="205" r="7"/><circle cx="790" cy="205" r="7"/><circle cx="810" cy="205" r="7"/><circle cx="830" cy="205" r="7"/>
              <circle cx="330" cy="265" r="7"/><circle cx="350" cy="265" r="7"/><circle cx="370" cy="265" r="7"/><circle cx="480" cy="265" r="7"/><circle cx="500" cy="265" r="7"/><circle cx="520" cy="265" r="7"/><circle cx="630" cy="265" r="7"/><circle cx="650" cy="265" r="7"/><circle cx="670" cy="265" r="7"/><circle cx="790" cy="265" r="7"/><circle cx="810" cy="265" r="7"/><circle cx="830" cy="265" r="7"/>
            </g>
          </svg>
          <p class="visual-caption">General strengths of each format, rated 1–5. Use your own insights to see what works for your audience.</p>
        </div>
      </div>
    </section>

    <!-- REELS -->
    <section class="section white">
      <div class="container split">
        <div class="reveal">
          <p class="eyebrow">Reels</p>
          <h2>Reels: your growth engine</h2>
          <ul class="tip-list">
            <li><strong>Hook in 1–2 seconds</strong> with motion and bold on-screen text.</li>
            <li><strong>Keep it short.</strong> Under 30 seconds is easier to rewatch, but longer works if it holds attention.</li>
            <li><strong>Leave room for the interface.</strong> Keep text away from the bottom and right edges.</li>
            <li><strong>Make it "sendable."</strong> Relatable moments and useful tips get shared in DMs.</li>
            <li><strong>Post original content.</strong> Reposts with another app's watermark get less reach.</li>
            <li><strong>Choose a cover</strong> that looks good in the 3:4 profile grid crop.</li>
            <li><strong>Try Trial Reels</strong> to test an idea on non-followers first.</li>
          </ul>
        </div>
        <div class="reveal">
          <!-- Reel safe zones -->
          <div class="visual-frame cream" style="max-width:340px;margin-inline:auto">
            <svg viewBox="0 0 270 480" role="img" aria-label="Diagram of Reel safe zones: keep text in the center, avoid the bottom caption area and right-side buttons">
              <rect x="0" y="0" width="270" height="480" rx="18" fill="#4a2c18"/>
              <rect x="0" y="0" width="270" height="60" rx="18" fill="#17120e" opacity=".6"/>
              <rect x="0" y="370" width="270" height="110" fill="#17120e" opacity=".6"/>
              <rect x="215" y="200" width="55" height="170" fill="#17120e" opacity=".6"/>
              <rect x="20" y="75" width="185" height="280" rx="12" fill="none" stroke="#d9bf9f" stroke-width="3" stroke-dasharray="8 6"/>
              <text x="112" y="205" text-anchor="middle" font-family="Fraunces, Georgia, serif" font-size="22" font-weight="700" fill="#f6eee2">Safe zone</text>
              <text x="112" y="230" text-anchor="middle" font-family="Inter, sans-serif" font-size="12" fill="#d9bf9f">put text &amp; faces here</text>
              <text x="135" y="36" text-anchor="middle" font-family="Inter, sans-serif" font-size="11" fill="#d9bf9f">top bar</text>
              <text x="110" y="430" text-anchor="middle" font-family="Inter, sans-serif" font-size="11" fill="#d9bf9f">caption + audio area</text>
              <text x="243" y="290" text-anchor="middle" font-family="Inter, sans-serif" font-size="11" fill="#d9bf9f" transform="rotate(90 243 290)">buttons</text>
            </svg>
          </div>
          <p class="visual-caption">Reel safe zones (9:16, 1080×1920)</p>
        </div>
      </div>
    </section>

    <!-- CAROUSEL ANATOMY -->
    <section class="section">
      <div class="container">
        <div class="section-head reveal">
          <p class="eyebrow">Carousels</p>
          <h2>Anatomy of a carousel people save</h2>
          <p class="section-intro">Carousels can get a second chance in the feed. If someone skips the post, Instagram may show it to them again starting on slide 2, so make slide 2 a strong hook as well.</p>
        </div>
        <div class="reveal">
          <svg viewBox="0 0 1000 260" role="img" aria-label="Carousel structure: slide 1 hook, slide 2 second hook, slides 3 to 6 value, slide 7 summary, slide 8 call to action">
            <g font-family="Inter, sans-serif" text-anchor="middle">
              <rect x="0" y="20" width="150" height="188" rx="14" fill="#17120e"/>
              <text x="75" y="100" font-family="Fraunces, Georgia, serif" font-size="22" font-weight="700" fill="#f6eee2">Hook</text>
              <text x="75" y="126" font-size="12" fill="#d9bf9f">bold title</text>
              <text x="75" y="144" font-size="12" fill="#d9bf9f">+ promise</text>

              <rect x="170" y="20" width="150" height="188" rx="14" fill="#6b4226"/>
              <text x="245" y="100" font-family="Fraunces, Georgia, serif" font-size="22" font-weight="700" fill="#f6eee2">Hook #2</text>
              <text x="245" y="126" font-size="12" fill="#ecdfcb">the "why"</text>
              <text x="245" y="144" font-size="12" fill="#ecdfcb">or a teaser</text>

              <rect x="340" y="20" width="320" height="188" rx="14" fill="#f6eee2" stroke="#17120e" stroke-width="2"/>
              <rect x="356" y="36" width="64" height="156" rx="8" fill="#ecdfcb"/><rect x="432" y="36" width="64" height="156" rx="8" fill="#ecdfcb"/><rect x="508" y="36" width="64" height="156" rx="8" fill="#ecdfcb"/><rect x="584" y="36" width="64" height="156" rx="8" fill="#ecdfcb"/>
              <text x="500" y="108" font-family="Fraunces, Georgia, serif" font-size="22" font-weight="700" fill="#17120e">The value</text>
              <text x="500" y="132" font-size="12" fill="#6f6257">one idea per slide</text>

              <rect x="680" y="20" width="150" height="188" rx="14" fill="#d9bf9f"/>
              <text x="755" y="100" font-family="Fraunces, Georgia, serif" font-size="22" font-weight="700" fill="#17120e">Recap</text>
              <text x="755" y="126" font-size="12" fill="#4a2c18">screenshot-able</text>
              <text x="755" y="144" font-size="12" fill="#4a2c18">summary</text>

              <rect x="850" y="20" width="150" height="188" rx="14" fill="#b07b4f" stroke="#17120e" stroke-width="2"/>
              <text x="925" y="100" font-family="Fraunces, Georgia, serif" font-size="22" font-weight="700" fill="#fff">CTA</text>
              <text x="925" y="126" font-size="12" fill="#fff">"Save for later"</text>
              <text x="925" y="144" font-size="12" fill="#fff">"Send to a friend"</text>

              <g font-size="13" font-weight="700" fill="#6f6257">
                <text x="75" y="238">Slide 1</text><text x="245" y="238">Slide 2</text><text x="500" y="238">Slides 3–6</text><text x="755" y="238">Slide 7</text><text x="925" y="238">Slide 8</text>
              </g>
            </g>
          </svg>
        </div>
        <div class="card-grid" style="margin-top:36px">
          <article class="card reveal"><h3>📐 Use 4:5 size</h3><p>1080×1350 takes up more of the feed than square posts.</p></article>
          <article class="card reveal"><h3>🔤 Big, readable text</h3><p>About 30 words per slide at most. If you have to squint, it's too small.</p></article>
          <article class="card reveal"><h3>➡️ Add a swipe cue</h3><p>An arrow or a cut-off element at the edge encourages people to swipe.</p></article>
          <article class="card reveal"><h3>🎵 Add music</h3><p>Photo carousels with audio can also appear in the Reels feed.</p></article>
        </div>
      </div>
    </section>

    <!-- CAPTIONS, HASHTAGS, STORIES -->
    <section class="section white">
      <div class="container">
        <div class="section-head reveal"><p class="eyebrow">The extras</p><h2>Captions, hashtags &amp; Stories</h2></div>
        <div class="value-grid">
          <article class="card cream reveal">
            <h3>✍️ Captions</h3>
            <ul class="tip-list">
              <li>The first line is a second hook. Don't waste it.</li>
              <li>Use keywords people search for. Instagram search reads captions.</li>
              <li>End with a question or a clear call-to-action.</li>
              <li>Short line breaks make captions easier to read.</li>
            </ul>
          </article>
          <article class="card cream reveal">
            <h3># Hashtags</h3>
            <ul class="tip-list">
              <li>Use 3–5 relevant tags. Instagram now caps posts at 5 hashtags.</li>
              <li>Pick specific tags (#smallbizmarketing), not huge ones (#love).</li>
              <li>Keywords in your caption matter more than hashtags now.</li>
              <li>Check the Hashtags line in a post's insights to see if they bring reach.</li>
            </ul>
          </article>
          <article class="card cream reveal">
            <h3>⭕ Stories</h3>
            <ul class="tip-list">
              <li>Post daily to stay at the front of your followers' Story bar.</li>
              <li>Polls, quizzes and question stickers boost replies.</li>
              <li>Share new posts to Stories to give them a push.</li>
              <li>Save your best Stories to Highlights on your profile.</li>
            </ul>
          </article>
        </div>
      </div>
    </section>

    <!-- SIZES -->
    <section class="section">
      <div class="container narrow">
        <div class="section-head center reveal"><p class="eyebrow">Cheat sheet</p><h2>Instagram image &amp; video sizes</h2></div>
        <div class="table-wrap reveal">
          <table>
            <thead><tr><th>Format</th><th>Ratio</th><th>Pixels</th></tr></thead>
            <tbody>
              <tr><td>Reels &amp; Stories</td><td>9:16</td><td>1080 × 1920</td></tr>
              <tr><td>Feed / carousel (best)</td><td>4:5</td><td>1080 × 1350</td></tr>
              <tr><td>Profile grid preview</td><td>3:4</td><td>1080 × 1440</td></tr>
              <tr><td>Square post</td><td>1:1</td><td>1080 × 1080</td></tr>
              <tr><td>Profile photo</td><td>1:1</td><td>320 × 320</td></tr>
            </tbody>
          </table>
        </div>
      </div>
    </section>

    <!-- INSIGHTS -->
    <section class="section dark">
      <div class="container split">
        <div class="reveal">
          <p class="eyebrow">Instagram insights</p>
          <h2>What to check after every post</h2>
          <p class="section-intro">Tap "View insights" under any post (you'll need a Professional account). Wait 48–72 hours before judging a post.</p>
        </div>
        <ul class="tip-list reveal">
          <li><strong>Views &amp; accounts reached:</strong> How far did it go? Check the percentage of non-followers.</li>
          <li><strong>Sends (shares):</strong> Your best sign of reaching new people.</li>
          <li><strong>Saves:</strong> Shows your content is useful enough to keep.</li>
          <li><strong>Average watch time (Reels):</strong> Compare it to the Reel's length.</li>
          <li><strong>Skip rate (Reels):</strong> How many people swiped away in the first 3 seconds.</li>
          <li><strong>Profile activity &amp; follows:</strong> Did the post turn viewers into followers?</li>
        </ul>
      </div>
    </section>

    <!-- DO DONT -->
    <section class="section">
      <div class="container">
        <div class="section-head center reveal"><p class="eyebrow">Quick guide</p><h2>Do this, not that</h2></div>
        <div class="do-dont reveal">
          <div class="do"><h3>✅ Do</h3><ul>
            <li>Keep a consistent look and color palette</li>
            <li>Reply to every comment in the first hour</li>
            <li>Post Stories daily, even simple ones</li>
            <li>Collaborate using the Collab post feature</li>
            <li>Repurpose your top carousels as Reels</li>
          </ul></div>
          <div class="dont"><h3>🚫 Don't</h3><ul>
            <li>Buy followers (it kills your engagement rate)</li>
            <li>Use more than 5 or unrelated hashtags</li>
            <li>Post TikToks with the watermark still on</li>
            <li>Ask for likes with "like if you agree" bait</li>
            <li>Judge a post in the first hour</li>
          </ul></div>
        </div>
      </div>
    </section>

    <!-- CHECKLIST -->
    <section id="checklist" class="section white">
      <div class="container narrow">
        <div class="reveal">
          <p class="eyebrow">Before you hit share</p>
          <h2>Pre-posting checklist</h2>
          <p class="section-intro">Tick things off as you go. Your progress is saved in this browser.</p>
        </div>
        <div class="progress"><div class="progress-bar" id="progressBar"></div></div>
        <p class="progress-text" id="progressText">0 of 10 done</p>
        <ul class="checklist" id="checklistItems">
          <li><label><input type="checkbox"> The first second or slide has a strong hook</label></li>
          <li><label><input type="checkbox"> Slide 2 works as a second hook (carousels)</label></li>
          <li><label><input type="checkbox"> Correct size: 9:16 for Reels, 4:5 for feed posts</label></li>
          <li><label><input type="checkbox"> Text is inside the safe zone</label></li>
          <li><label><input type="checkbox"> Caption starts strong and includes keywords</label></li>
          <li><label><input type="checkbox"> 3–5 specific hashtags</label></li>
          <li><label><input type="checkbox"> Clear CTA: save, send, comment or follow</label></li>
          <li><label><input type="checkbox"> Alt text and captions added</label></li>
          <li><label><input type="checkbox"> Shared to Stories after posting</label></li>
          <li><label><input type="checkbox"> 15–30 minutes blocked to reply to comments</label></li>
        </ul>
        <button class="btn btn-ghost" id="resetChecklist">Reset checklist</button>
      </div>
    </section>

    <section class="section">
      <div class="container">
        <div class="cta-band reveal">
          <div><h2>Want to grow on TikTok too?</h2><p>Get hook formulas, video structure and TikTok analytics.</p></div>
          <a href="<?php echo esc_url(home_url('/tiktok-tips/')); ?>" class="btn btn-primary">TikTok tips →</a>
        </div>
      </div>
    </section>
  </main>
<?php get_footer(); ?>

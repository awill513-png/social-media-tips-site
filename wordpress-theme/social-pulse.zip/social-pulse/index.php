<?php get_header(); ?>
<main>
  <section class="page-hero">
    <div class="container narrow">
      <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
        <h1><?php the_title(); ?></h1>
        <div class="lead"><?php the_content(); ?></div>
      <?php endwhile; else : ?>
        <h1>Nothing here yet</h1>
      <?php endif; ?>
    </div>
  </section>
</main>
<?php get_footer(); ?>

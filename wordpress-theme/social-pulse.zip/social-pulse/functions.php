<?php
function social_pulse_setup() {
    add_theme_support('title-tag');
    add_theme_support('html5', array('script', 'style'));
}
add_action('after_setup_theme', 'social_pulse_setup');

function social_pulse_assets() {
    wp_enqueue_style('social-pulse-fonts', 'https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,600;9..144,700&family=Inter:wght@400;500;600;700&display=swap', array(), null);
    wp_enqueue_style('social-pulse-style', get_stylesheet_uri(), array(), '1.0.0');
    wp_enqueue_script('social-pulse-script', get_template_directory_uri() . '/script.js', array(), '1.0.0', true);
}
add_action('wp_enqueue_scripts', 'social_pulse_assets');

/* On theme activation, create the About / TikTok Tips / Instagram Tips pages
   and set a static front page so the menu links work right away. */
function social_pulse_create_pages() {
    $pages = array('about' => 'About', 'tiktok-tips' => 'TikTok Tips', 'instagram-tips' => 'Instagram Tips', 'home' => 'Home');
    foreach ($pages as $slug => $title) {
        if (!get_page_by_path($slug)) {
            wp_insert_post(array('post_title' => $title, 'post_name' => $slug, 'post_status' => 'publish', 'post_type' => 'page'));
        }
    }
    $home = get_page_by_path('home');
    if ($home) {
        update_option('show_on_front', 'page');
        update_option('page_on_front', $home->ID);
    }
    if (get_option('permalink_structure') === '') {
        update_option('permalink_structure', '/%postname%/');
    }
    flush_rewrite_rules();
}
add_action('after_switch_theme', 'social_pulse_create_pages');



  <footer class="site-footer">
    <div class="container">
      <div class="footer-grid">
        <div>
          <a href="<?php echo esc_url(home_url('/')); ?>" class="logo"><span class="logo-mark"><svg viewBox="0 0 24 24"><path d="M3 17l5-5 4 4 8-9" fill="none" stroke="#17120e" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/></svg></span>Social Pulse</a>
          <p style="margin-top:14px">Social media analytics and posting tips, explained simply.</p>
        </div>
        <div>
          <h4>Pages</h4>
          <ul><li><a href="<?php echo esc_url(home_url('/')); ?>">Home</a></li><li><a href="<?php echo esc_url(home_url('/about/')); ?>">About</a></li><li><a href="<?php echo esc_url(home_url('/tiktok-tips/')); ?>">TikTok Tips</a></li><li><a href="<?php echo esc_url(home_url('/instagram-tips/')); ?>">Instagram Tips</a></li></ul>
        </div>
        <div>
          <h4>Quick links</h4>
          <ul><li><a href="<?php echo esc_url(home_url('/')); ?>#metrics">Key metrics</a></li><li><a href="<?php echo esc_url(home_url('/')); ?>#calculator">Engagement calculator</a></li><li><a href="<?php echo esc_url(home_url('/instagram-tips/')); ?>#checklist">Pre-post checklist</a></li></ul>
        </div>
      </div>
      <div class="footer-bottom">© <span id="year">2026</span> Social Pulse. Benchmarks are general guidance; your own data matters most.</div>
    </div>
  </footer>

  
<?php wp_footer(); ?>
</body>
</html>
